# DiscordBot-Login — site de présentation

Site statique en HTML/CSS, prêt à importer dans un dépôt GitHub et à publier avec GitHub Pages.

## Fichiers
- `index.html` : page d'accueil
- `style.css` : styles
- `confidentialite.html` : modèle de politique de confidentialité à compléter
- `contact.html` : page de contact à compléter

## Avant publication
1. Remplacer les champs entre crochets dans `confidentialite.html` et `contact.html`.
2. Vérifier que les fonctionnalités annoncées existent réellement.
3. Vérifier les permissions du lien d'invitation Discord.
4. Ne jamais publier de Client Secret, jeton de bot, cookie ou secret de compte.

## Publication avec GitHub Pages
Dans le dépôt GitHub : **Settings → Pages → Deploy from a branch**, choisir `main` et `/ (root)`, puis enregistrer.
